Becareful when editing "title.tfx" try to follow the format but I only added it so people could customize the colors of text.
To many characters it will cause it to get funky.